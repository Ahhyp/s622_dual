# C4.3 S4 W7 -- combined Gazebo launch for the end-to-end transport flow.
#
# This is the "W7-A wiring" launch: ONE launch that brings up
#   * the W5 world (table + support + sample),
#   * the W6 robot description (dual-arm xacro WITH the DetachableJoint plugin),
#   * gz_ros2_control + the same controller set as s622_dual_arm_qp.launch.py,
#   * the three weld topics (attach / detach / weld_state) bridged gz<->ros,
#   * the weld pose stream (Pose_V -> tf2_msgs/TFMessage) the snap measurement
#     needs, and
#   * the transport executor.
#
# It deliberately does NOT start MoveIt and does NOT claim the flow is validated:
# W7-B/W7-C evidence comes from what actually happens at runtime, not from this
# file existing.  Everything here is simulated (Gazebo) and MUST NOT be read as a
# real-hardware or real-time result.
#
#   ros2 launch gz_launch c43_s4_full_flow.launch.py                # headless
#   ros2 launch gz_launch c43_s4_full_flow.launch.py gui:=true      # with GUI
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_param_builder import load_xacro

import os
from pathlib import Path


def generate_launch_description():
    gz_share = get_package_share_directory("gz_launch")
    desc_share = get_package_share_directory("s622_moveit_descriptions")
    qp_share = get_package_share_directory("dual_arm_qp_controller")
    ex_share = get_package_share_directory("dual_arm_transport_executor")

    gui_arg = DeclareLaunchArgument("gui", default_value="false",
                                    description="Gazebo GUI (false = server only)")
    executor_arg = DeclareLaunchArgument(
        "executor", default_value="true",
        description="start the transport executor (needed for the weld guards)")
    world_name = "c43_s4_world"

    set_model_path = SetEnvironmentVariable(
        "IGN_GAZEBO_RESOURCE_PATH",
        os.path.join(gz_share, "models") + ":" + os.environ.get("IGN_GAZEBO_RESOURCE_PATH", ""),
    )

    world_file = os.path.join(gz_share, "worlds", f"{world_name}.sdf")
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory("ros_gz_sim"), "launch", "gz_sim.launch.py")
        ),
        launch_arguments=[("gz_args", [
            world_file + " -r -v 4",
            PythonExpression(["' -s' if '", LaunchConfiguration("gui"), "' == 'false' else ''"]),
        ])],
    )

    controllers_yaml = os.environ.get(
        "QP_CONTROLLERS_YAML",
        os.path.join(qp_share, "config", "dual_arm_qp_gazebo_controllers.yaml"))
    # The ONLY difference from the production profile: the description carries the
    # DetachableJoint plugin (W6).  Every other mapping is copied verbatim so the
    # kinematics and the controller set stay identical.
    urdf = load_xacro(
        Path(os.path.join(gz_share, "config", "c43_s4_dual_arm_gazebo.urdf.xacro")),
        mappings={
            "instantiate": "false",
            "include_camera_visual": "false",
            "include_global_camera": "false",
            "include_wrist_camera": "false",
            "finger_stop_gap": "0.0",
            "gripper_stop_block": "false",
            "gripper_force_plugins": "false",
            "arm_command_mode": "position",
            "arm_position_gain": os.environ.get("QP_ARM_POSITION_GAIN", "20.0"),
            "controllers_yaml": controllers_yaml,
        },
    ).replace("package://s622_moveit_descriptions", desc_share)

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{"robot_description": urdf}],
        output="screen",
    )

    spawn_robot = TimerAction(
        period=5.0,
        actions=[Node(package="ros_gz_sim", executable="create",
                      arguments=["-string", urdf, "-x", "0.0", "-y", "0.0", "-z", "0.0",
                                 "-R", "0", "-P", "0", "-Y", "0", "-name", "s622_dual_arm",
                                 # Spawn at the controller's standing configuration (home_q):
                                 # the QP refuses to start transport when the arms are not there,
                                 # and it does not drive the arms to home by itself.
                                 '-J', 'left_j1', '2.795036909814', '-J', 'left_j2', '-1.706950857914', '-J', 'left_j3', '1.279963524342', '-J', 'left_j4', '-1.143808993223', '-J', 'left_j5', '-1.570796326795', '-J', 'left_j6', '-0.346555743776', '-J', 'right_j1', '0.346555743776', '-J', 'right_j2', '-1.434641795676', '-J', 'right_j3', '-1.279963524342', '-J', 'right_j4', '-1.997783660367', '-J', 'right_j5', '1.570796326795', '-J', 'right_j6', '-2.795036909814'],
                      output="screen")],
    )

    def spawner(names):
        return Node(package="controller_manager", executable="spawner",
                    arguments=names + ["-c", "/controller_manager",
                                       "--controller-manager-timeout", "90"],
                    output="screen")

    spawn_controllers = TimerAction(
        period=12.0,
        actions=[
            spawner(["joint_state_broadcaster"]),
            spawner(["left_hand_controller", "right_hand_controller"]),
            TimerAction(period=3.0, actions=[spawner(["dual_arm_qp_controller"])]),
        ],
    )

    # gz <-> ros plumbing.  Attach/detach are ROS->GZ because the plugin is a
    # subscriber only (W6-0: it does not advertise the topics).  weld_state is
    # GZ->ROS (StringMsg).  pose/info is bridged as TFMessage because that is the
    # only ROS type ros_gz_bridge maps Pose_V onto; the executor reads
    # child_frame_id == "<model>::<link>" from it.
    bridges = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            f"/world/{world_name}/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock",
            f"/world/{world_name}/pose/info@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V",
            "/c43/attach@std_msgs/msg/Empty]ignition.msgs.Empty",
            "/c43/detach@std_msgs/msg/Empty]ignition.msgs.Empty",
            "/c43/weld_state@std_msgs/msg/String[ignition.msgs.StringMsg",
        ],
        output="screen",
    )

    executor = TimerAction(
        period=16.0,
        actions=[Node(
            package="dual_arm_transport_executor",
            executable="c43_s4_executor",
            name="c43_s4_transport_executor",
            parameters=[
                os.path.join(ex_share, "config", "c43_s4_executor.yaml"),
                {
                    # Pose_V bridges to TFMessage with the gz scoped link names.
                    "weld_parent_frame": "s622_dual_arm::left_wrist3_link",
                    "weld_child_frame": "c43_sample::base_link",
                    "weld_pose_topic": "/c43/weld_pose",
                    "artifacts_dir": os.environ.get("C43_W7_ARTIFACTS", "/tmp/c43_s4_w7"),
                    "run_id": os.environ.get("C43_W7_RUN_ID", "c43_s4_w7_run"),
                },
            ],
            output="screen",
        )],
        condition=IfCondition(LaunchConfiguration("executor")),
    )

    return LaunchDescription([
        gui_arg, executor_arg, set_model_path, gazebo, bridges,
        robot_state_publisher, spawn_robot, spawn_controllers, executor,
    ])
